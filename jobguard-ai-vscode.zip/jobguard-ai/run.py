#!/usr/bin/env python3
"""
JobGuard AI — Entry Point
Run this file to start the application: python run.py
"""
import os
import sys
import threading
import webbrowser

def load_env():
    env_file = os.path.join(os.path.dirname(__file__), '.env')
    if os.path.exists(env_file):
        with open(env_file) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, _, val = line.partition('=')
                    os.environ.setdefault(key.strip(), val.strip())

def open_browser(port):
    import time
    time.sleep(1.5)
    webbrowser.open(f'http://localhost:{port}')

if __name__ == '__main__':
    load_env()

    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('DEBUG', 'False').lower() == 'true'

    print("=" * 55)
    print("  JobGuard AI — Job Fraud Detection Platform")
    print("=" * 55)
    print(f"  Server  : http://localhost:{port}")
    print(f"  Debug   : {debug}")
    print(f"  Database: jobguard.db (auto-created)")
    print(f"  ML Model: fraud_model.pkl (auto-trained)")
    print("=" * 55)
    print("  Demo logins:")
    print("    User  → rahul@gmail.com  / user123")
    print("    Admin → admin@jobguard.ai / admin123")
    print("=" * 55)
    print()

    if not debug:
        t = threading.Thread(target=open_browser, args=(port,), daemon=True)
        t.start()

    from app import app
    app.run(host='0.0.0.0', port=port, debug=debug)
