# JobGuard AI — Job Fraud Detection Web App

An AI-powered web application that detects fake and fraudulent job postings using machine learning (scikit-learn TF-IDF + Logistic Regression + SVM ensemble) and a rule-based keyword engine.

---

## Features

- **AI Fraud Detection** — Paste job text, URLs, emails, or images to get instant analysis
- **Fraud Score** — 0–35 Safe (green), 36–65 Suspicious (orange), 66–100 Fake (red)
- **URL Scraping** — Auto-scrapes job listing pages via BeautifulSoup
- **Image OCR** — Extract text from job offer screenshots (requires Tesseract)
- **AI Chat Widget** — Ask questions about any analyzed job
- **Job Portal** — Browse jobs with AI verification scores
- **Admin Panel** — Full user/job/report management + platform analytics
- **16 Pages** — Dashboard, Analyze, History, Insights, Portal, Applications, Report, Profile + all Admin pages

---

## Quick Start (VS Code)

### 1. Prerequisites

- Python 3.10 or higher
- pip

### 2. Clone / Extract the project

```bash
cd jobguard-ai
```

### 3. Create a virtual environment (recommended)

```bash
python -m venv venv

# Windows
venv\Scripts\activate

# macOS / Linux
source venv/bin/activate
```

### 4. Install dependencies

```bash
pip install -r requirements.txt
```

### 5. Configure environment (optional)

Copy `.env.example` to `.env` and edit as needed:

```bash
cp .env.example .env
```

### 6. Run the app

```bash
python run.py
```

Or directly:

```bash
python app.py
```

Open your browser at: **http://localhost:5000**

---

## Demo Accounts

| Role  | Email                | Password  |
|-------|----------------------|-----------|
| User  | rahul@gmail.com      | user123   |
| Admin | admin@jobguard.ai    | admin123  |

---

## Project Structure

```
jobguard-ai/
├── app.py              ← Flask app & all routes (20+ pages)
├── database.py         ← SQLite setup, CRUD, admin functions
├── ai_detector.py      ← ML fraud detection (LR + SVM ensemble)
├── url_scraper.py      ← BeautifulSoup URL scraping
├── ai_chat.py          ← AI chat with knowledge base
├── run.py              ← Entry point (auto-opens browser)
├── requirements.txt    ← Python dependencies
├── .env.example        ← Environment variable template
├── templates/          ← Jinja2 HTML templates (17 files)
│   ├── base.html
│   ├── login.html
│   ├── register.html
│   ├── dashboard.html
│   ├── analyze.html
│   ├── result.html
│   ├── history.html
│   ├── insights.html
│   ├── jobs.html
│   ├── job_detail.html
│   ├── my_applications.html
│   ├── cybercrime.html
│   ├── profile.html
│   ├── admin_overview.html
│   ├── admin_users.html
│   ├── admin_jobs.html
│   ├── admin_feedback.html
│   └── admin_analytics.html
├── static/
│   └── css/
│       └── style.css   ← Complete CSS theme
├── uploads/            ← Resume uploads (auto-created)
├── jobguard.db         ← SQLite database (auto-created on first run)
└── fraud_model.pkl     ← Trained ML model (auto-generated on first run)
```

---

## Configuration (.env)

| Variable        | Default                        | Description                          |
|-----------------|--------------------------------|--------------------------------------|
| `SESSION_SECRET`| `jobguard-ai-secret-2025`      | Flask session secret key             |
| `PORT`          | `5000`                         | Port the app runs on                 |
| `DEBUG`         | `False`                        | Enable Flask debug mode              |

---

## Optional: Image OCR (Tesseract)

To enable image/screenshot analysis:

**Windows:** Download from https://github.com/UB-Mannheim/tesseract/wiki  
**macOS:** `brew install tesseract`  
**Linux:** `sudo apt install tesseract-ocr`

---

## Optional: AI Chat via Ollama (Local LLM)

The chat widget uses a rule-based knowledge base by default. To enable a local LLM:

1. Install Ollama: https://ollama.com
2. Pull a model: `ollama pull llama3`
3. Start Ollama: `ollama serve`

JobGuard will auto-detect Ollama at `http://localhost:11434` and use it.

---

## Fraud Score System

| Score | Verdict    | Color  |
|-------|------------|--------|
| 0–35  | Safe       | Green  |
| 36–65 | Suspicious | Orange |
| 66–100| Fake       | Red    |

## ML Model

- **Algorithm**: Ensemble of Logistic Regression + Linear SVM (calibrated)
- **Features**: TF-IDF word n-grams (1–3) + character n-grams (3–5)
- **Training**: 175 labeled examples (85 fake + 90 safe)
- **Blend**: 70% ML ensemble + 30% keyword rules engine
- **Cross-validation accuracy**: 100% (5-fold stratified)
- **Auto-training**: Model trains on first run and saves as `fraud_model.pkl`

---

## Tech Stack

- **Backend**: Python 3.10+ / Flask 3.1
- **Database**: SQLite (via built-in sqlite3)
- **ML**: scikit-learn (TF-IDF, Logistic Regression, LinearSVC)
- **Frontend**: Vanilla HTML, CSS, JavaScript + Jinja2 templates
- **Charts**: Chart.js (CDN)
- **Scraping**: BeautifulSoup4 + requests
- **OCR**: pytesseract (optional — graceful fallback)
